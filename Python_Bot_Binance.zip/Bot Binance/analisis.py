import pandas as pd
from datetime import datetime
import os

log_file = 'registro_operaciones.csv'

try:
    if not os.path.isfile(log_file) or os.path.getsize(log_file) == 0:
        print("⚠️ No hay operaciones registradas aún.")
    else:
        df = pd.read_csv(log_file, encoding='utf-8')
        total_ops = len(df)
        compras = df[df['Señal'] == 'BUY']
        ventas = df[df['Señal'] == 'SELL']

        print("\n📊 Resumen de Operaciones:")
        print(f"Total de operaciones: {total_ops}")
        print(f"🟢 Compras: {len(compras)}")
        print(f"🔴 Ventas: {len(ventas)}")

        ultima = df.iloc[-1]
        print("\n🕒 Última operación:")
        print(f"{ultima['Fecha']}: {ultima['Señal']} {ultima['Cantidad']} {ultima['Símbolo']} a {ultima['Precio']}€")

        if not compras.empty and not ventas.empty:
            beneficio = ventas['Precio'].mean() - compras['Precio'].mean()
            print(f"\n💰 Beneficio teórico: {beneficio:.2f} €")
        else:
            print("💰 Beneficio teórico: Datos insuficientes")

except Exception as e:
    print(f"⚠️ Error al analizar: {e}")
