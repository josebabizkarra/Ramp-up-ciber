import time
import pandas as pd
import ta
from binance.client import Client
from binance.enums import *
from telegram import Update, Bot, InputFile
from telegram.ext import Application, CommandHandler, ContextTypes
import asyncio
import nest_asyncio
import logging
from datetime import datetime
import os
import matplotlib.pyplot as plt

nest_asyncio.apply()

# ============== CONFIGURACIÓN ==============

API_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
API_SECRET = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'

client = Client(API_KEY, API_SECRET, testnet=True)

TELEGRAM_TOKEN = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
TELEGRAM_CHAT_ID = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'

symbol = 'BTCEUR'
interval = Client.KLINE_INTERVAL_1MINUTE

log_file = 'registro_operaciones.csv'
movimientos_log = 'movimientos.log'
error_log_file = 'errors.log'

# ============== BILLETERA SIMULADA ==============

capital_inicial_eur = 100.0
capital_eur = capital_inicial_eur
capital_btc = 0.0

bot_activo = True

# ============== LOGGING ==============

logging.basicConfig(filename=error_log_file, level=logging.ERROR,
                    format='%(asctime)s:%(levelname)s:%(message)s')

# ============== CREAR CSV SI NO EXISTE ==============

if not os.path.isfile(log_file):
    df_init = pd.DataFrame(columns=['Fecha', 'Señal', 'Cantidad', 'Símbolo', 'Precio'])
    df_init.to_csv(log_file, index=False)
    print("✅ Archivo registro_operaciones.csv creado automáticamente.")

# ============== FUNCIONES DE LOG MOVIMIENTOS ==============

def registrar_movimiento(tipo, cantidad):
    with open(movimientos_log, 'a') as f:
        f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {tipo}: {cantidad:.2f} EUR\n")

# ============== TELEGRAM FUNCIONES ==============

async def enviar_mensaje_telegram(texto):
    bot = Bot(token=TELEGRAM_TOKEN)
    await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=texto)

# ============== ESTRATEGIA ==============

def obtener_datos():
    frame = pd.DataFrame(client.get_historical_klines(symbol, interval, "2 days ago UTC"))
    frame = frame.iloc[:, 0:6]
    frame.columns = ['Time', 'Open', 'High', 'Low', 'Close', 'Volume']
    frame['Time'] = pd.to_datetime(frame['Time'], unit='ms')
    frame['Close'] = frame['Close'].astype(float)
    frame.set_index('Time', inplace=True)
    return frame

def aplicar_indicadores(df):
    df['SMA7'] = df['Close'].rolling(window=7).mean()
    df['SMA25'] = df['Close'].rolling(window=25).mean()
    df['RSI'] = ta.momentum.rsi(df['Close'], window=14)
    return df

def generar_senal(df):
    if df['SMA7'].iloc[-1] > df['SMA25'].iloc[-1] and df['RSI'].iloc[-1] < 70:
        return 1  # BUY
    elif df['SMA7'].iloc[-1] < df['SMA25'].iloc[-1] and df['RSI'].iloc[-1] > 30:
        return -1  # SELL
    else:
        return 0  # HOLD

# ============== REGISTRO CSV ==============

def registrar_operacion(senal, precio, cantidad, simbolo):
    encabezados = ['Fecha', 'Señal', 'Cantidad', 'Símbolo', 'Precio']
    try:
        df = pd.read_csv(log_file)
    except FileNotFoundError:
        df = pd.DataFrame(columns=encabezados)

    nueva_fila = pd.DataFrame([{
        'Fecha': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'Señal': 'BUY' if senal == 1 else 'SELL',
        'Cantidad': cantidad,
        'Símbolo': simbolo,
        'Precio': precio
    }])

    df = pd.concat([df, nueva_fila], ignore_index=True)
    df.to_csv(log_file, index=False)

# ============== CICLO TRADING ==============

async def ejecutar_operacion(senal):
    global capital_eur, capital_btc

    try:
        precio_actual = float(client.get_symbol_ticker(symbol=symbol)['price'])
        cantidad_eur = capital_eur * 0.10
        cantidad_btc = cantidad_eur / precio_actual

        if senal == 1:
            if capital_eur >= cantidad_eur:
                capital_eur -= cantidad_eur
                capital_btc += cantidad_btc
                registrar_operacion(senal, precio_actual, cantidad_btc, symbol)
                mensaje = f"🟢 Compra: {cantidad_btc:.6f} BTC (~{cantidad_eur:.2f} EUR) a {precio_actual:.2f} EUR\n💶 EUR restante: {capital_eur:.2f}\n₿ BTC en cartera: {capital_btc:.6f}"
                await enviar_mensaje_telegram(mensaje)
                print(mensaje)
            else:
                print("❌ No hay suficiente EUR para comprar.")
        elif senal == -1:
            if capital_btc >= cantidad_btc:
                capital_btc -= cantidad_btc
                capital_eur += cantidad_btc * precio_actual
                registrar_operacion(senal, precio_actual, cantidad_btc, symbol)
                mensaje = f"🔴 Venta: {cantidad_btc:.6f} BTC a {precio_actual:.2f} EUR\n💶 EUR en cartera: {capital_eur:.2f}\n₿ BTC restante: {capital_btc:.6f}"
                await enviar_mensaje_telegram(mensaje)
                print(mensaje)
            else:
                print("❌ No hay suficiente BTC para vender.")
        else:
            print("⏸️ Sin señal nueva, esperando próximo análisis...")

    except Exception as e:
        logging.error(f"Error en ejecutar_operacion: {e}")
        await enviar_mensaje_telegram(f"⚠️ Error al ejecutar operación: {e}")

async def ciclo_trading():
    while True:
        try:
            df = obtener_datos()
            df = aplicar_indicadores(df)
            senal = generar_senal(df)

            print(f"🔍 Señal detectada: {senal} ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})")
            await ejecutar_operacion(senal)

        except Exception as e:
            logging.error(f"Error en ciclo_trading: {e}")
            await enviar_mensaje_telegram(f"⚠️ Error en el ciclo de trading: {e}")

        await asyncio.sleep(60)

# ============== COMANDOS TELEGRAM ==============

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 El bot está activo y funcionando correctamente en Testnet BTC/EUR.")

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        global capital_eur, capital_btc

        precio_actual = float(client.get_symbol_ticker(symbol=symbol)['price'])
        valor_btc_en_eur = capital_btc * precio_actual
        capital_total = capital_eur + valor_btc_en_eur
        beneficio = capital_total - capital_inicial_eur

        if beneficio > 0:
            resultado = "✅ Ganando dinero 🚀"
        elif beneficio < 0:
            resultado = "🔻 Perdiendo dinero 😓"
        else:
            resultado = "🔵 Equilibrio, sin ganancias ni pérdidas."

        balance_text = (
            f"💼 Capital inicial: {capital_inicial_eur:.2f} EUR\n"
            f"💶 EUR disponible: {capital_eur:.2f} EUR\n"
            f"₿ BTC disponible: {capital_btc:.6f} BTC (~{valor_btc_en_eur:.2f} EUR)\n"
            f"💰 Valor total estimado: {capital_total:.2f} EUR\n"
            f"💸 Beneficio/Pérdida neta: {beneficio:.2f} EUR\n"
            f"{resultado}"
        )

        await update.message.reply_text(balance_text)

    except Exception as e:
        logging.error(f"Error en balance: {e}")
        await update.message.reply_text(f"⚠️ Error al calcular balance: {e}")

async def saldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"💶 Saldo disponible: {capital_eur:.2f} EUR")

async def depositar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global capital_eur
    try:
        cantidad = float(context.args[0])
        if cantidad <= 0:
            await update.message.reply_text("La cantidad a depositar debe ser mayor que cero.")
            return

        capital_eur += cantidad
        registrar_movimiento("Depósito", cantidad)
        await update.message.reply_text(f"✅ Depósito recibido: {cantidad:.2f} EUR\n💶 Nuevo saldo: {capital_eur:.2f} EUR")
    except (IndexError, ValueError):
        await update.message.reply_text("Uso correcto: /depositar cantidad")

async def retirar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global capital_eur
    try:
        cantidad = float(context.args[0])
        if cantidad <= 0:
            await update.message.reply_text("La cantidad a retirar debe ser mayor que cero.")
            return

        if cantidad > capital_eur:
            await update.message.reply_text(f"❌ No puedes retirar más de tu saldo actual: {capital_eur:.2f} EUR")
            return

        capital_eur -= cantidad
        registrar_movimiento("Retiro", cantidad)
        await update.message.reply_text(f"✅ Retiro realizado: {cantidad:.2f} EUR\n💶 Nuevo saldo: {capital_eur:.2f} EUR")
    except (IndexError, ValueError):
        await update.message.reply_text("Uso correcto: /retirar cantidad")

async def analisis(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = pd.read_csv(log_file)
        if df.empty:
            await update.message.reply_text("No hay operaciones registradas aún para analizar 📊.")
            return

        total_ops = len(df)
        compras = df[df['Señal'] == 'BUY']
        ventas = df[df['Señal'] == 'SELL']

        texto = f"📊 Análisis operaciones:\nTotal: {total_ops}\nCompras: {len(compras)}\nVentas: {len(ventas)}\n"

        ultima = df.iloc[-1]
        texto += f"\n🕒 Última operación:\n{ultima['Fecha']}: {ultima['Señal']} {ultima['Cantidad']} {ultima['Símbolo']} a {ultima['Precio']}€"

        await update.message.reply_text(texto)

    except Exception as e:
        logging.error(f"Error en analisis: {e}")
        await update.message.reply_text(f"⚠️ Error en análisis: {e}")

async def log(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if os.path.isfile(error_log_file) and os.path.getsize(error_log_file) > 0:
            await context.bot.send_document(chat_id=update.effective_chat.id, document=InputFile(error_log_file))
        else:
            await update.message.reply_text("No hay errores registrados. Todo limpio ✅")
    except Exception as e:
        logging.error(f"Error en comando log: {e}")
        await update.message.reply_text(f"⚠️ Error al enviar el log: {e}")

async def ultimo_trade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = pd.read_csv(log_file)
        if df.empty:
            await update.message.reply_text("No hay operaciones registradas aún.")
            return

        ultima = df.iloc[-1]
        texto = f"🕒 Última operación:\n{ultima['Fecha']}\n📈 Señal: {ultima['Señal']}\n💰 Cantidad: {ultima['Cantidad']} {ultima['Símbolo']}\n💶 Precio: {ultima['Precio']}€"
        await update.message.reply_text(texto)

    except Exception as e:
        logging.error(f"Error en comando ultimo_trade: {e}")
        await update.message.reply_text(f"⚠️ Error al obtener la última operación: {e}")

async def grafico(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        df = pd.read_csv(log_file)
        if df.empty:
            await update.message.reply_text("No hay operaciones registradas para generar el gráfico 📊.")
            return

        historial = obtener_datos()
        historial = aplicar_indicadores(historial)

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True)

        ax1.plot(historial.index, historial['Close'], label='Precio de cierre', linewidth=1)
        ax1.plot(historial.index, historial['SMA7'], label='SMA 7', linestyle='--', linewidth=1)
        ax1.plot(historial.index, historial['SMA25'], label='SMA 25', linestyle='--', linewidth=1)

        compras = df[df['Señal'] == 'BUY']
        ventas = df[df['Señal'] == 'SELL']

        if not compras.empty:
            ax1.scatter(pd.to_datetime(compras['Fecha']), compras['Precio'], marker='^', color='green', label='Compras', s=100)
        if not ventas.empty:
            ax1.scatter(pd.to_datetime(ventas['Fecha']), ventas['Precio'], marker='v', color='red', label='Ventas', s=100)

        ax1.set_title('Historial de Operaciones BTC/EUR 📈')
        ax1.set_ylabel('Precio (€)')
        ax1.legend()
        ax1.grid(True)

        ax2.plot(historial.index, historial['RSI'], label='RSI', color='purple')
        ax2.axhline(70, color='red', linestyle='--', linewidth=0.5)
        ax2.axhline(30, color='green', linestyle='--', linewidth=0.5)
        ax2.set_ylabel('RSI')
        ax2.set_xlabel('Fecha')
        ax2.legend()
        ax2.grid(True)

        image_path = 'grafico_operaciones.png'
        plt.tight_layout()
        plt.savefig(image_path)
        plt.close()

        await context.bot.send_photo(chat_id=update.effective_chat.id, photo=open(image_path, 'rb'))

    except Exception as e:
        logging.error(f"Error en comando grafico: {e}")
        await update.message.reply_text(f"⚠️ Error al generar el gráfico: {e}")

# ============== START BOT ==============

async def start_bot():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("saldo", saldo))
    app.add_handler(CommandHandler("depositar", depositar))
    app.add_handler(CommandHandler("retirar", retirar))
    app.add_handler(CommandHandler("analisis", analisis))
    app.add_handler(CommandHandler("log", log))
    app.add_handler(CommandHandler("ultimo_trade", ultimo_trade))
    app.add_handler(CommandHandler("grafico", grafico))

    print("✅ Bot trader profesional iniciado con BTC/EUR y simulación de capital dinámico con depósitos y retiros.")
    await enviar_mensaje_telegram("🚀 Bot iniciado correctamente con capital inicial de 100€, y depósitos/retiros habilitados.")

    asyncio.create_task(ciclo_trading())
    await app.run_polling()

if __name__ == '__main__':
    asyncio.run(start_bot())
